-- Hämta alla ägare som har ett djur med tillhörande info
SELECT 
	CONCAT(o.FirstName, ' ', o.LastName) as owner_name,
    a.Name,
    s.Name,
    a.BirthDate 
FROM animal a
JOIN owner o ON a.OwnerID = o.OwnerID
JOIN species s ON a.SpeciesID = s.SpeciesID